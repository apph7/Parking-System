create definer = root@localhost view vehicle_parking as
select `v`.`id`               AS `vehicle_id`,
       `v`.`license_plate`    AS `license_plate`,
       `v`.`vehicle_type`     AS `vehicle_type`,
       `v`.`user_id`          AS `user_id`,
       `v`.`owner_name`       AS `owner_name`,
       `v`.`photo`            AS `vehicle_photo`,
       `pr`.`id`              AS `record_id`,
       `pr`.`parking_spot_id` AS `parking_spot_id`,
       `pr`.`entry_time`      AS `entry_time`,
       `pr`.`exit_time`       AS `exit_time`,
       `pr`.`fee`             AS `fee`,
       `pr`.`status`          AS `parking_status`,
       `pr`.`create_time`     AS `parking_create_time`
from (`parking`.`vehicles` `v` join `parking`.`parking_record` `pr` on ((`v`.`license_plate` = `pr`.`license_plate`)));

