create definer = root@localhost view user_payment as
select `v`.`id`               AS `vehicle_id`,
       `v`.`user_id`          AS `user_id`,
       `v`.`license_plate`    AS `license_plate`,
       `pr`.`id`              AS `parking_record_id`,
       `pr`.`parking_spot_id` AS `parking_spot_id`,
       `ps`.`location`        AS `location`,
       `pr`.`entry_time`      AS `entry_time`,
       `pr`.`exit_time`       AS `exit_time`,
       `p`.`id`               AS `id`,
       `p`.`amount`           AS `payment_amount`,
       `p`.`payment_time`     AS `payment_time`,
       `p`.`payment_method`   AS `payment_method`
from (((`parking`.`vehicles` `v` join `parking`.`parking_record` `pr`
        on ((`v`.`license_plate` = `pr`.`license_plate`))) join `parking`.`parking_spot` `ps`
       on ((`pr`.`parking_spot_id` = `ps`.`id`))) join `parking`.`payment` `p`
      on ((`pr`.`id` = `p`.`parking_record_id`)));

