create definer = root@localhost view v_bulletin as
select `parking`.`bulletin`.`id`                                                               AS `id`,
       `parking`.`bulletin`.`title`                                                            AS `title`,
       `parking`.`bulletin`.`content`                                                          AS `content`,
       `parking`.`bulletin`.`publish_time`                                                     AS `publish_time`,
       `parking`.`bulletin`.`author`                                                           AS `author`,
       (case when (`parking`.`bulletin`.`end_time` < now()) then 'inactive' else 'active' end) AS `status`,
       `parking`.`bulletin`.`last_update_time`                                                 AS `last_update_time`,
       `parking`.`bulletin`.`end_time`                                                         AS `end_time`
from `parking`.`bulletin`;

